exports.productValidation = async (req, res, next) => {
  // console.log(req.body);
  next();
};
