exports.getDate = () => {
  const d = Date.now();
  return d;
};
